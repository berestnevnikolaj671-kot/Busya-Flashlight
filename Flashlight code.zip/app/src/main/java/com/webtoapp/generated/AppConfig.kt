package com.webtoapp.generated

object AppConfig {
    const val APP_NAME = "Busya Flashlight фонарик"
    const val TARGET_URL = ""

    const val ACTIVATION_ENABLED = false
    val ACTIVATION_CODES = listOf()

    const val AD_BLOCK_ENABLED = false
    val AD_BLOCK_RULES = listOf()

    const val ANNOUNCEMENT_ENABLED = true
    const val ANNOUNCEMENT_TITLE = "ВАЖНОЕ ПРИМЕЧАНИЕ!"
    const val ANNOUNCEMENT_CONTENT = "Зачем приложению нужен доступ к камере? Вы вероятно настрожитесь что фонарик требует такое разрешение. Однако это не странно так как без камеры на 99% смартфонах фонарь не включить. Это разрешение требует и наш фонарик, и наши конкуренты. Камера используется только для фонарика, никакие фото/видео не делаются. В следующем всплывающем экране разрешите доступ к камере."
    const val ANNOUNCEMENT_LINK = ""
    const val ANNOUNCEMENT_SHOW_ONCE = true

    const val JAVASCRIPT_ENABLED = true
    const val DOM_STORAGE_ENABLED = true
    const val ZOOM_ENABLED = true
    const val DESKTOP_MODE = false
}